﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Globalization;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for SalidaWindow.xaml
    /// </summary>
    public partial class SalidaWindow : Window
    {
        public SalidaWindow()
        {
            InitializeComponent();
            dpFecha.SelectedDate = DateTime.Today;
            txtHora.Text = DateTime.Now.ToString("HH:mm");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTipoDocumento.Text) ||
                string.IsNullOrWhiteSpace(txtNumeroDocumento.Text))
            {
                MessageBox.Show("TipoDocumento y Número Documento son obligatorios.");
                return;
            }

            if (!double.TryParse(txtPeso.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out _) ||
                !double.TryParse(txtPesoIngreso.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out _) ||
                !double.TryParse(txtPesoSalida.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
            {
                MessageBox.Show("Revisa los campos numéricos (usa punto como separador).");
                return;
            }

            if (!TimeSpan.TryParseExact(txtHora.Text, "hh\\:mm", CultureInfo.InvariantCulture, out _))
            {
                MessageBox.Show("Hora inválida. Usa formato HH:mm");
                return;
            }

            MessageBox.Show("Salida registrada correctamente.", "OK",
                            MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}
