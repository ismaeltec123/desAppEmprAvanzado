﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02
{
    /// <summary>
    /// Lógica de interacción para MantenimientosWindow.xaml
    /// </summary>
    public partial class MantenimientosWindow : Window
    {
        public MantenimientosWindow()
        {
            InitializeComponent();
        }

        private void Conductores_Click(object sender, RoutedEventArgs e)
        {
            // Lista de Conductores (según el lab)
            var w = new ConductoresWindow { Owner = this };
            w.ShowDialog();
        }

        private void Transportistas_Click(object sender, RoutedEventArgs e)
        {
            // No requerido explícitamente: dejamos stub
            MessageBox.Show("Mantenimiento de Transportistas (no implementado).");
        }

        private void Camiones_Click(object sender, RoutedEventArgs e)
        {
            var w = new CamionWindow { Owner = this };
            w.ShowDialog();
        }

        private void Productos_Click(object sender, RoutedEventArgs e)
        {
            // No requerido explícitamente: dejamos stub
            MessageBox.Show("Mantenimiento de Productos (no implementado).");
        }
    }
}
