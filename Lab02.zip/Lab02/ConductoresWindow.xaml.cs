﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for ConductoresWindow.xaml
    /// </summary>
    public partial class ConductoresWindow : Window
    {
        private readonly ObservableCollection<RowConductor> _rows = new();

        public ConductoresWindow()
        {
            InitializeComponent();
            dgConductores.ItemsSource = _rows;
        }

        private void Agregar_Click(object sender, RoutedEventArgs e)
        {
            _rows.Add(new RowConductor { Placa = "XXX-000", PesoMaximo = 0, PesoVacio = 0 });
        }

        private void Eliminar_Click(object sender, RoutedEventArgs e)
        {
            if (dgConductores.SelectedItem is RowConductor r)
                _rows.Remove(r);
            else
                MessageBox.Show("Seleccione una fila.");
        }
    }

    public class RowConductor
    {
        public double PesoMaximo { get; set; }
        public string Placa { get; set; } = "";
        public double PesoVacio { get; set; }
    }
}
