﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for CamionWindow.xaml
    /// </summary>
    public partial class CamionWindow : Window
    {
        public CamionWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPlaca.Text))
            {
                MessageBox.Show("La placa es obligatoria.");
                return;
            }

            if (!double.TryParse(txtPesoMaximo.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out _) ||
                !double.TryParse(txtPesoVacio.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
            {
                MessageBox.Show("Revisa los pesos (usa punto como separador).");
                return;
            }

            MessageBox.Show("Camión registrado.", "OK",
                            MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}
