﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02
{
    /// <summary>
    /// Lógica de interacción para OperacionesWindow.xaml
    /// </summary>
    public partial class OperacionesWindow : Window
    {
        public OperacionesWindow()
        {
            InitializeComponent();
        }

        private void Ingresos_Click(object sender, RoutedEventArgs e)
        {
            // Pantalla de Ingresos (no requerida en el enunciado)
            MessageBox.Show("Ingresos (no implementado).");
        }

        private void Salida_Click(object sender, RoutedEventArgs e)
        {
            // Abre la ventana de registro de Salidas
            var w = new SalidaWindow { Owner = this };
            w.ShowDialog();
        }
    }
}
