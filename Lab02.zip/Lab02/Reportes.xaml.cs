﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02
{
    /// <summary>
    /// Lógica de interacción para ReportesWindow.xaml
    /// </summary>
    public partial class ReportesWindow : Window
    {
        public ReportesWindow()
        {
            InitializeComponent();
        }

        private void Cargas_Click(object sender, RoutedEventArgs e)
        {
            // Reporte de cargas (stub)
            MessageBox.Show("Reporte de Cargas (no implementado).");
        }

        private void RepIngresos_Click(object sender, RoutedEventArgs e)
        {
            // Reporte de ingresos (stub)
            MessageBox.Show("Reporte de Ingresos (no implementado).");
        }

        private void RepSalidas_Click(object sender, RoutedEventArgs e)
        {
            // Reporte de salidas (stub)
            MessageBox.Show("Reporte de Salidas (no implementado).");
        }
    }
}
