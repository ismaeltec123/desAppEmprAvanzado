﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        public Home()
        {
            InitializeComponent();
            Loaded += Home_Loaded;
        }

        private void Home_Loaded(object sender, RoutedEventArgs e)
        {
            // Busca los 3 botones por la etiqueta visible dentro de cada tarjeta
            Button? btnOperaciones = GetButtonByLabel("Operaciones");
            Button? btnMantenimientos = GetButtonByLabel("Mantenimientos");
            Button? btnReportes = GetButtonByLabel("Reportes");

            if (btnOperaciones != null) btnOperaciones.Click += BtnOperaciones_Click;
            if (btnMantenimientos != null) btnMantenimientos.Click += BtnMantenimientos_Click;
            if (btnReportes != null) btnReportes.Click += BtnReportes_Click;
        }

        // ===== Handlers de los 3 botones del Home =====
        private void BtnOperaciones_Click(object sender, RoutedEventArgs e)
        {
            // Abre Lab02.OperacionesWindow
            var w = new OperacionesWindow { Owner = this };
            w.ShowDialog();
        }

        private void BtnMantenimientos_Click(object sender, RoutedEventArgs e)
        {
            // Abre Lab02.MantenimientosWindow
            var w = new MantenimientosWindow { Owner = this };
            w.ShowDialog();
        }

        private void BtnReportes_Click(object sender, RoutedEventArgs e)
        {
            // Abre Lab02.ReportesWindow
            var w = new ReportesWindow { Owner = this };
            w.ShowDialog();
        }

        // ===== Utilidad: encuentra un Button cuyo StackPanel interno tiene un TextBlock con ese texto =====
        private Button? GetButtonByLabel(string label)
        {
            foreach (var btn in FindVisualChildren<Button>(this))
            {
                if (btn.Content is StackPanel sp)
                {
                    var tb = sp.Children.OfType<TextBlock>().LastOrDefault();
                    if (tb != null && tb.Text.Trim().Equals(label, StringComparison.OrdinalIgnoreCase))
                        return btn;
                }
            }
            return null;
        }

        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj == null) yield break;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                if (child is T match) yield return match;

                foreach (T childOfChild in FindVisualChildren<T>(child))
                    yield return childOfChild;
            }
        }
    }
}
