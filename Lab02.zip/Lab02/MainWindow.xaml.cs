﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var user = txtUsuario.Text.Trim();
            var pass = (txtPassword as PasswordBox)?.Password;

            if (user == "admin" && pass == "1234")
            {
                var home = new Home();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Usuario o password incorrecto.", "Validación",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
